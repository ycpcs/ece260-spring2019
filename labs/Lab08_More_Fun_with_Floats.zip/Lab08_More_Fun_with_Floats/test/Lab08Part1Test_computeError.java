/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */

import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Label.*;
import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.FloatRegister.*;
import static edu.gvsu.mipsunit.munit.MUnit.DoubleRegister.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab08Part1Test_computeError {

    //////////////////////////////////////////////////////////////////////////////////////////
    // Test computeError procedure
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 100
    public void verify_sX_regs_are_preserved_in_computeError_procedure() {
        set(s0, 7880);  // set some dummy value to ensure that it is preserved in procedure
        set(s1, 7881);  // set some dummy value to ensure that it is preserved in procedure
        set(s2, 7882);  // set some dummy value to ensure that it is preserved in procedure
        set(s3, 7883);  // set some dummy value to ensure that it is preserved in procedure
        set(s4, 7884);  // set some dummy value to ensure that it is preserved in procedure
        set(s5, 7885);  // set some dummy value to ensure that it is preserved in procedure
        set(s6, 7886);  // set some dummy value to ensure that it is preserved in procedure
        set(s7, 7887);  // set some dummy value to ensure that it is preserved in procedure
        run("computeError");
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s0 -- ", 7880, get(s0));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s1 -- ", 7881, get(s1));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s2 -- ", 7882, get(s2));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s3 -- ", 7883, get(s3));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s4 -- ", 7884, get(s4));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s5 -- ", 7885, get(s5));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s6 -- ", 7886, get(s6));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"computeError\" procedure, you used $s7 -- ", 7887, get(s7));
    }
    
    @Test(timeout=1000)  // 101
    public void verify_fX_regs_are_preserved_in_computeError_procedure() {
        setDouble(DoubleRegister.f0,  7800.7800);
        setDouble(DoubleRegister.f2,  7802.7802);
        setDouble(DoubleRegister.f4,  7804.7804);
        setDouble(DoubleRegister.f6,  7806.7806);
        setDouble(DoubleRegister.f8,  7808.7808);
        setDouble(DoubleRegister.f10, 7810.7810);
        setDouble(DoubleRegister.f12, 7812.7812);
        setDouble(DoubleRegister.f14, 7814.7814);
        setDouble(DoubleRegister.f16, 7816.7816);
        setDouble(DoubleRegister.f18, 7818.7818);
        setDouble(DoubleRegister.f20, 7820.7820);
        setDouble(DoubleRegister.f22, 7822.7822);
        setDouble(DoubleRegister.f24, 7824.7824);
        setDouble(DoubleRegister.f26, 7826.7826);
        setDouble(DoubleRegister.f28, 7828.7828);
        setDouble(DoubleRegister.f30, 7830.7830);
        run("computeError");
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f0 -- ",  7800.7800, getDouble(DoubleRegister.f0),  0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f2 -- ",  7802.7802, getDouble(DoubleRegister.f2),  0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f4 -- ",  7804.7804, getDouble(DoubleRegister.f4),  0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f6 -- ",  7806.7806, getDouble(DoubleRegister.f6),  0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f8 -- ",  7808.7808, getDouble(DoubleRegister.f8),  0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f10 -- ", 7810.7810, getDouble(DoubleRegister.f10), 0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f12 -- ", 7812.7812, getDouble(DoubleRegister.f12), 0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f14 -- ", 7814.7814, getDouble(DoubleRegister.f14), 0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f16 -- ", 7816.7816, getDouble(DoubleRegister.f16), 0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f18 -- ", 7818.7818, getDouble(DoubleRegister.f18), 0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f20 -- ", 7820.7820, getDouble(DoubleRegister.f20), 0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f22 -- ", 7822.7822, getDouble(DoubleRegister.f22), 0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f24 -- ", 7824.7824, getDouble(DoubleRegister.f24), 0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f26 -- ", 7826.7826, getDouble(DoubleRegister.f26), 0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f28 -- ", 7828.7828, getDouble(DoubleRegister.f28), 0);
        assertEquals("\n\tYou must preserve any $fX register that you use in your \"computeError\" procedure, you used $f30 -- ", 7830.7830, getDouble(DoubleRegister.f30), 0);        
    }
    
    @Test(timeout=1000)  // 102
    public void verify_unaligned_stack_pointer_after_calling_computeError_procedure() {
        double arg0 = 1.0;
        double arg1 = 1.0;
        long arg0_bits = Double.doubleToRawLongBits(arg0);
        long arg1_bits = Double.doubleToRawLongBits(arg1);
        set(a1, ((int)(arg0_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg0
        set(a0,  (int)(arg0_bits & 0xFFFFFFFF));         // low  32 bits of arg0
        set(a3, ((int)(arg1_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg1
        set(a2,  (int)(arg1_bits & 0xFFFFFFFF));         // low  32 bits of arg1
        run("computeError");
        assertEquals("\n\tAfter calling \"computeError\" procedure, stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    
    @Test(timeout=1000)  // 103
    public void verify_aligned_stack_pointer_after_calling_computeError_procedure() {
        double arg0 = 1.0;
        double arg1 = 1.0;
        long arg0_bits = Double.doubleToRawLongBits(arg0);
        long arg1_bits = Double.doubleToRawLongBits(arg1);
        int sp_backup = get(sp);  // backup the existing $sp register
        int aligned_sp = sp_backup & 0xFFFFFFF0;
        set(sp, aligned_sp);      // manually align stack pointer to the doubleword boundary
        set(a1, ((int)(arg0_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg0
        set(a0,  (int)(arg0_bits & 0xFFFFFFFF));         // low  32 bits of arg0
        set(a3, ((int)(arg1_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg1
        set(a2,  (int)(arg1_bits & 0xFFFFFFFF));         // low  32 bits of arg1
        run("computeError");
        assertEquals("\n\tAfter calling \"computeError\" procedure, stack pointer should be 0x7FFFEFF0 -- ", aligned_sp, get(sp));
        set(sp, sp_backup);       // reset the $sp register to the value that was backed up earlier
    }
    
    @Test(timeout=1000)  // 104
    public void verify_computeError_procedure_returns_correct_result_0() {
        double arg0 = 1.0;
        double arg1 = 1.0;
        long arg0_bits = Double.doubleToRawLongBits(arg0);
        long arg1_bits = Double.doubleToRawLongBits(arg1);
        set(a1, ((int)(arg0_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg0
        set(a0,  (int)(arg0_bits & 0xFFFFFFFF));         // low  32 bits of arg0
        set(a3, ((int)(arg1_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg1
        set(a2,  (int)(arg1_bits & 0xFFFFFFFF));         // low  32 bits of arg1
        run("computeError");
        long v1_v0_bits = (((long)get(v1)) << 32) | (get(v0) & 0xffffffffL);
        double v1_v0_val = Double.longBitsToDouble(v1_v0_bits);
        assertEquals("\n\tWhen calling \"computeError(1.0, 1.0)\", return value in ($v1+$v0) should be 0.0 -- ", 0.0, v1_v0_val, 0);
    }
    
    @Test(timeout=1000)  // 105
    public void verify_computeError_procedure_returns_correct_result_1() {
        double arg0 = 1.0;
        double arg1 = 0.0;
        long arg0_bits = Double.doubleToRawLongBits(arg0);
        long arg1_bits = Double.doubleToRawLongBits(arg1);
        set(a1, ((int)(arg0_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg0
        set(a0,  (int)(arg0_bits & 0xFFFFFFFF));         // low  32 bits of arg0
        set(a3, ((int)(arg1_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg1
        set(a2,  (int)(arg1_bits & 0xFFFFFFFF));         // low  32 bits of arg1
        run("computeError");
        long v1_v0_bits = (((long)get(v1)) << 32) | (get(v0) & 0xffffffffL);
        double v1_v0_val = Double.longBitsToDouble(v1_v0_bits);
        assertEquals("\n\tWhen calling \"computeError(1.0, 0.0)\", return value in ($v1+$v0) should be 1.0 -- ", 1.0, v1_v0_val, 0);
    }
    
    @Test(timeout=1000)  // 106
    public void verify_computeError_procedure_returns_correct_result_2() {
        double arg0 = 0.0;
        double arg1 = 1.0;
        long arg0_bits = Double.doubleToRawLongBits(arg0);
        long arg1_bits = Double.doubleToRawLongBits(arg1);
        set(a1, ((int)(arg0_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg0
        set(a0,  (int)(arg0_bits & 0xFFFFFFFF));         // low  32 bits of arg0
        set(a3, ((int)(arg1_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg1
        set(a2,  (int)(arg1_bits & 0xFFFFFFFF));         // low  32 bits of arg1
        run("computeError");
        long v1_v0_bits = (((long)get(v1)) << 32) | (get(v0) & 0xffffffffL);
        double v1_v0_val = Double.longBitsToDouble(v1_v0_bits);
        assertEquals("\n\tWhen calling \"computeError(0.0, 1.0)\", return value in ($v1+$v0) should be 1.0 -- ", 1.0, v1_v0_val, 0);
    }
    
    @Test(timeout=1000)  // 107
    public void verify_computeError_procedure_returns_correct_result_3() {
        double arg0 = 1.5239;
        double arg1 = 8.7355;
        long arg0_bits = Double.doubleToRawLongBits(arg0);
        long arg1_bits = Double.doubleToRawLongBits(arg1);
        set(a1, ((int)(arg0_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg0
        set(a0,  (int)(arg0_bits & 0xFFFFFFFF));         // low  32 bits of arg0
        set(a3, ((int)(arg1_bits >> 32) & 0xFFFFFFFF));  // high 32 bits of arg1
        set(a2,  (int)(arg1_bits & 0xFFFFFFFF));         // low  32 bits of arg1
        run("computeError");
        long v1_v0_bits = (((long)get(v1)) << 32) | (get(v0) & 0xffffffffL);
        double v1_v0_val = Double.longBitsToDouble(v1_v0_bits);
        assertEquals("\n\tWhen calling \"computeError(1.5239, 8.7355)\", return value in ($v1+$v0) should be 7.2116 -- ", 7.2116, v1_v0_val, 0);
    }
    //////////////////////////////////////////////////////////////////////////////////////////
}
