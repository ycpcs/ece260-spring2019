/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */

import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.FloatRegister.*;
import static edu.gvsu.mipsunit.munit.MUnit.DoubleRegister.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab07Part1Test {

    //////////////////////////////////////////////////////////////////////////////////////////
    // Verify memory contents are setup properly
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 100
    public void verify_singles_memory_contents() {  
        run("exitProgram");
        float[] singles_array_expected = {1.4563f, 2.4564f, -4.2342f, 65.334f};
        float[] singles_array_actual = getFloats("singles", 0, 4);
        assertArrayEquals("\n\tContents of \"singles\" array are incorrect", singles_array_expected, singles_array_actual, 0);
    }
    
    @Test(timeout=1000)  // 101
    public void verify_doubles_memory_contents() {  
        run("exitProgram");
        double[] doubles_array_expected = {1.4563, 2.4564, -4.2342, 65.334};
        double[] doubles_array_actual = getDoubles("doubles", 0, 4);
        assertArrayEquals("\n\tContents of \"singles\" array are incorrect", doubles_array_expected, doubles_array_actual, 0);
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Test processing on singles array
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 102
    public void verify_fX_regs_contain_final_results_of_singles_computations() {
        setFloat(FloatRegister.f4, 7884.7884f);  // set some dummy value
        setFloat(FloatRegister.f5, 7885.7885f);  // set some dummy value
        setFloat(FloatRegister.f6, 7886.7886f);  // set some dummy value
        run("ece260_main");
        float f4_val = getFloat(FloatRegister.f4);
        float f5_val = getFloat(FloatRegister.f5);
        float f6_val = getFloat(FloatRegister.f6);
        assertEquals("\n\tWhen done with computations on singles array, value stored in $f4 should be 3.9127 -- ", 3.9127f, f4_val, 0);
        assertEquals("\n\tWhen done with computations on singles array, value stored in $f5 should be -1.7778001 -- ", -1.7778001f, f5_val, 0);
        assertEquals("\n\tWhen done with computations on singles array, value stored in $f6 should be 61.0998 -- ", 61.0998f, f6_val, 0);
    }

    @Test(timeout=1000)  // 103
    public void verify_sX_regs_contain_final_results_of_singles_computations() {
        set(s0, 7880);  // set some dummy value
        set(s1, 7881);  // set some dummy value
        set(s2, 7882);  // set some dummy value
        run("ece260_main");
        float s0_val = Float.intBitsToFloat(get(s0));
        assertEquals("\n\tWhen done with computations on singles array, your results should be moved into $sX registers, value stored in $s0 should be 3.9127 -- ", 3.9127f, s0_val, 0);
        float s1_val = Float.intBitsToFloat(get(s1));
        assertEquals("\n\tWhen done with computations on singles array, your results should be moved into $sX registers, value stored in $s1 should be -1.7778001 -- ", -1.7778001f, s1_val, 0);
        float s2_val = Float.intBitsToFloat(get(s2));
        assertEquals("\n\tWhen done with computations on singles array, your results should be moved into $sX registers, value stored in $s2 should be 61.0998 -- ", 61.0998f, s2_val, 0);
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Test processing on doubles array
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 104
    public void verify_fX_regs_contain_final_results_of_doubles_computations() {
        setDouble(DoubleRegister.f24, 7824.7824);  // set some dummy value
        setDouble(DoubleRegister.f26, 7826.7826);  // set some dummy value
        setDouble(DoubleRegister.f28, 7828.7828);  // set some dummy value
        run("ece260_main");
        double f24_val = getDouble(DoubleRegister.f24);
        double f26_val = getDouble(DoubleRegister.f26);
        double f28_val = getDouble(DoubleRegister.f28);
        assertEquals("\n\tWhen done with computations on doubles array, value stored in $f24 should be 3.9127 -- ", 3.9127, f24_val, 0);
        assertEquals("\n\tWhen done with computations on doubles array, value stored in $f26 should be -1.7778000000000005 -- ", -1.7778000000000005, f26_val, 0);
        assertEquals("\n\tWhen done with computations on doubles array, value stored in $f28 should be 61.0998 -- ", 61.0998, f28_val, 0);
    }
    
    @Test(timeout=1000)  // 105
    public void verify_tX_regs_contain_final_results_of_doubles_computations() {
        set(t0, 7880);  // set some dummy value
        set(t1, 7881);  // set some dummy value
        set(t2, 7882);  // set some dummy value
        set(t3, 7883);  // set some dummy value
        set(t4, 7884);  // set some dummy value
        set(t5, 7885);  // set some dummy value
        run("ece260_main");
        long t1_t0_bits = (((long)get(t1)) << 32) | (get(t0) & 0xffffffffL);
        double t1_t0_val = Double.longBitsToDouble(t1_t0_bits);
        assertEquals("\n\tWhen done with computations on doubles array, your results should be moved into $tX registers, value stored in $t1+$t0 should be 3.9127 -- ", 3.9127, t1_t0_val, 0);

        long t3_t2_bits = (((long)get(t3)) << 32) | (get(t2) & 0xffffffffL);
        double t3_t2_val = Double.longBitsToDouble(t3_t2_bits);
        assertEquals("\n\tWhen done with computations on doubles array, your results should be moved into $tX registers, value stored in $t3+$t2 should be -1.7778000000000005 -- ", -1.7778000000000005, t3_t2_val, 0);
        
        long t5_t4_bits = (((long)get(t5)) << 32) | (get(t4) & 0xffffffffL);
        double t5_t4_val = Double.longBitsToDouble(t5_t4_bits);
        assertEquals("\n\tWhen done with computations on doubles array, your results should be moved into $tX registers, value stored in $t5+$t4 should be 61.0998 -- ", 61.0998, t5_t4_val, 0);
    }
    //////////////////////////////////////////////////////////////////////////////////////////
}
