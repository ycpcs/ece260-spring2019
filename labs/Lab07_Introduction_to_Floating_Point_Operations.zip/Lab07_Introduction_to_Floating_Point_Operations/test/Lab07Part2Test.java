/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */

import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.FloatRegister.*;
import static edu.gvsu.mipsunit.munit.MUnit.DoubleRegister.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab07Part2Test {

    //////////////////////////////////////////////////////////////////////////////////////////
    // Verify memory contents are setup properly
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 200
    public void verify_eq1_memory_contents() {  
        run("exitProgram");
        float[] eq1_vals_array_expected = {25.9f, 3.14159265359f};
        float[] eq1_vals_array_actual = getFloats("eq1_vals", 0, 2);
        assertArrayEquals("\n\tContents of \"eq1_vals\" array are incorrect", eq1_vals_array_expected, eq1_vals_array_actual, 0);
    }
    
    @Test(timeout=1000)  // 201
    public void verify_eq2_memory_contents() {  
        run("exitProgram");
        double[] eq2_vals_array_expected = {-44.321, 9.12, 2.53, 1.25};
        double[] eq2_vals_array_actual = getDoubles("eq2_vals", 0, 4);
        assertArrayEquals("\n\tContents of \"eq2_vals\" array are incorrect", eq2_vals_array_expected, eq2_vals_array_actual, 0);
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Test processing on EQ#1
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 202
    public void verify_fX_regs_contain_final_results_of_eq1_computation() {
        setFloat(FloatRegister.f3, 7883.7883f);  // set some dummy value
        run("ece260_main");
        float f3_val = getFloat(FloatRegister.f3);
        assertEquals("\n\tWhen done with eq1_computation, value stored in $f3 should be 2107.4119 -- ", 2107.4119f, f3_val, 0);
    }
    
    @Test(timeout=1000)  // 203
    public void verify_sX_regs_contain_final_results_of_eq1_computation() {
        set(s0, 7880);  // set some dummy value to ensure that it is preserved in procedure
        run("ece260_main");
        float s0_val = Float.intBitsToFloat(get(s0));
        assertEquals("\n\tWhen done with eq1_computation, your result should be moved into register $s0, value stored in $s0 should be 2107.4119 -- ", 2107.4119f, s0_val, 0);
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Test processing on EQ#2
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 204
    public void verify_fX_regs_contain_final_results_of_eq2_computation() {
        setDouble(DoubleRegister.f28, 7828.7828);
        run("ece260_main");
        double f28_val = getDouble(DoubleRegister.f28);
        assertEquals("\n\tWhen done with eq2_computation, value stored in $f28 should be 4969.945195133508 -- ", 4969.945195133508, f28_val, 0);
    }
    
    @Test(timeout=1000)  // 205
    public void verify_tX_regs_contain_final_results_of_eq2_computation() {
        set(t0, 7880);  // set some dummy value
        set(t1, 7881);  // set some dummy value
        run("ece260_main");
        long t1_t0_bits = (((long)get(t1)) << 32) | (get(t0) & 0xffffffffL);
        double t1_t0_val = Double.longBitsToDouble(t1_t0_bits);
        assertEquals("\n\tWhen done with eq2_computation, your result should be moved into register $t1+$t0, value stored in $t1+$t0 should be 4969.945195133508 -- ", 4969.945195133508, t1_t0_val, 0);
    }
    //////////////////////////////////////////////////////////////////////////////////////////
}
