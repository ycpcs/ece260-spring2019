/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */

import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab05Part2Test {

    //////////////////////////////////////////////////////////////////////////////////////////
    // Multiply Tests
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 200
    public void verify_multiply_0() {
        set(v0, 9999);  // set some dummy value to ensure that it gets overwritten
        run("multiply", 0, 0);
        assertEquals("\n\tWhen multiplying '0 * 0', final value should be 0 -- ", 0, get(v0));
    }
    
    @Test(timeout=1000)  // 201
    public void verify_multiply_1() {
        set(v0, 9999);  // set some dummy value to ensure that it gets overwritten
        run("multiply", 10, 0);
        assertEquals("\n\tWhen multiplying '10 * 0', final value should be 0 -- ", 0, get(v0));
    }
    
    @Test(timeout=1000)  // 202
    public void verify_multiply_2() {
        set(v0, 9999);  // set some dummy value to ensure that it gets overwritten
        run("multiply", 10, 15);
        assertEquals("\n\tWhen multiplying '10 * 15', final value should be 0 -- ", 150, get(v0));
    }
    
    @Test(timeout=1000)  // 203
    public void verify_multiply_3() {
        set(v0, 9999);  // set some dummy value to ensure that it gets overwritten
        run("multiply", 131071, 16384);
        assertEquals("\n\tWhen multiplying '131071 * 16384', final value should be 2147467264 -- ", 2147467264, get(v0));
    }
    
    @Test(timeout=1000)  // 204
    public void verify_stack_pointer_after_calling_multiply() {
        run("multiply", 6, 6);
        assertEquals("\n\tAfter calling \"multiply\" procedure, stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Power Tests
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 205
    public void verify_no_tX_regs_in_power_procedure() {
        set(t0, 8880);  // set some dummy value to ensure that it doesn't overwritten
        set(t1, 8881);  // set some dummy value to ensure that it doesn't overwritten
        set(t2, 8882);  // set some dummy value to ensure that it doesn't overwritten
        set(t3, 8883);  // set some dummy value to ensure that it doesn't overwritten
        set(t4, 8884);  // set some dummy value to ensure that it doesn't overwritten
        set(t5, 8885);  // set some dummy value to ensure that it doesn't overwritten
        set(t6, 8886);  // set some dummy value to ensure that it doesn't overwritten
        set(t7, 8887);  // set some dummy value to ensure that it doesn't overwritten
        set(t8, 8888);  // set some dummy value to ensure that it doesn't overwritten
        set(t9, 8889);  // set some dummy value to ensure that it doesn't overwritten    
        run("power", 2, 3);
        assertEquals("\n\tDo NOT use any $tX registers in your \"power\" procedure, you used $t0 -- ", 8880, get(t0));
        assertEquals("\n\tDo NOT use any $tX registers in your \"power\" procedure, you used $t1 -- ", 8881, get(t1));
        assertEquals("\n\tDo NOT use any $tX registers in your \"power\" procedure, you used $t2 -- ", 8882, get(t2));
        assertEquals("\n\tDo NOT use any $tX registers in your \"power\" procedure, you used $t3 -- ", 8883, get(t3));
        assertEquals("\n\tDo NOT use any $tX registers in your \"power\" procedure, you used $t4 -- ", 8884, get(t4));
        assertEquals("\n\tDo NOT use any $tX registers in your \"power\" procedure, you used $t5 -- ", 8885, get(t5));
        assertEquals("\n\tDo NOT use any $tX registers in your \"power\" procedure, you used $t6 -- ", 8886, get(t6));
        assertEquals("\n\tDo NOT use any $tX registers in your \"power\" procedure, you used $t7 -- ", 8887, get(t7));
        assertEquals("\n\tDo NOT use any $tX registers in your \"power\" procedure, you used $t8 -- ", 8888, get(t8));
        assertEquals("\n\tDo NOT use any $tX registers in your \"power\" procedure, you used $t9 -- ", 8889, get(t9));
    }
    
    @Test(timeout=1000)  // 206
    public void verify_sX_regs_are_preserved_in_power_procedure() {
        set(s0, 7880);  // set some dummy value to ensure that it is preserved in power procedure
        set(s1, 7881);  // set some dummy value to ensure that it is preserved in power procedure
        set(s2, 7882);  // set some dummy value to ensure that it is preserved in power procedure
        set(s3, 7883);  // set some dummy value to ensure that it is preserved in power procedure
        set(s4, 7884);  // set some dummy value to ensure that it is preserved in power procedure
        set(s5, 7885);  // set some dummy value to ensure that it is preserved in power procedure
        set(s6, 7886);  // set some dummy value to ensure that it is preserved in power procedure
        set(s7, 7887);  // set some dummy value to ensure that it is preserved in power procedure
        run("power", 2, 3);
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"power\" procedure, you used $s0 -- ", 7880, get(s0));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"power\" procedure, you used $s1 -- ", 7881, get(s1));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"power\" procedure, you used $s2 -- ", 7882, get(s2));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"power\" procedure, you used $s3 -- ", 7883, get(s3));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"power\" procedure, you used $s4 -- ", 7884, get(s4));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"power\" procedure, you used $s5 -- ", 7885, get(s5));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"power\" procedure, you used $s6 -- ", 7886, get(s6));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"power\" procedure, you used $s7 -- ", 7887, get(s7));
    }
    
    @Test(timeout=1000)  // 207
    public void verify_stack_pointer_after_calling_power() {
        run("power", 2, 3);
        assertEquals("\n\tAfter calling \"power\" procedure, stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    
    @Test(timeout=1000)  // 208
    public void verify_power_procedure_when_exponent_is_zero() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("power", 25, 0);
        assertEquals("\n\tWhen exponent is 0, \"power\", procedure should return 1 -- ", 1, get(v0));
    }
    
    @Test(timeout=1000)  // 209
    public void verify_power_procedure_when_exponent_is_one() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("power", 25, 1);
        assertEquals("\n\tWhen calling \"power(25, 1)\", return value should be 25 -- ", 25, get(v0));
    }
    
    @Test(timeout=1000)  // 210
    public void verify_power_procedure_positive_vals_0() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("power", 2, 3);
        assertEquals("\n\tWhen calling \"power(2, 3)\", return value should be 8 -- ", 8, get(v0));
    }
    
    @Test(timeout=1000)  // 211
    public void verify_power_procedure_positive_vals_1() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("power", 4, 6);
        assertEquals("\n\tWhen calling \"power(4, 6)\", return value should be 4096 -- ", 4096, get(v0));
    }
    
    @Test(timeout=1000)  // 212
    public void verify_power_procedure_negative_base_value() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("power", -4, 3);
        assertEquals("\n\tWhen calling \"power(-4, 3)\", return value should be -64 -- ", -64, get(v0));
    }
    
    @Test(timeout=1000)  // 213
    public void verify_power_procedure_negative_exponent_value() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("power", 4, -3);
        assertEquals("\n\tWhen calling \"power(4, -3)\", return value should be 1 -- ", 1, get(v0));
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Main Tests
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 214
    public void verify_arguments_are_passed_to_power_procedure() {
        set(s0, 2);
        set(s1, 4);
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("ece260_main");
        assertEquals("\n\tWhen calling \"power(2, 4)\" procedure, return value should be 16. Make sure $aX registers are populated -- ", 16, get(v0));
    }
    
    @Test(timeout=1000)  // 215
    public void verify_final_result_stored_properly() {
        set(s0, 2);
        set(s1, 4);
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("ece260_main");
        assertEquals("\n\tWhen calling \"power(2, 4)\" procedure, return value should be stored in $s2 -- ", 16, get(s2));
    }
    
    @Test(timeout=1000)  // 216
    public void verify_stack_pointer_after_running_complete_program() {
        set(s0, 2);
        set(s1, 4);
        run("ece260_main");
        assertEquals("\n\tAfter running program, stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    //////////////////////////////////////////////////////////////////////////////////////////
}
