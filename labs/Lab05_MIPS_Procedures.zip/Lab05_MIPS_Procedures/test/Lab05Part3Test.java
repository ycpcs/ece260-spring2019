/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */

import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab05Part3Test {
    
    //////////////////////////////////////////////////////////////////////////////////////////
    // Fibonacci Tests
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 300
    public void verify_sX_regs_are_preserved_in_fib_procedure() {
        set(s0, 7880);  // set some dummy value to ensure that it is preserved in procedure
        set(s1, 7881);  // set some dummy value to ensure that it is preserved in procedure
        set(s2, 7882);  // set some dummy value to ensure that it is preserved in procedure
        set(s3, 7883);  // set some dummy value to ensure that it is preserved in procedure
        set(s4, 7884);  // set some dummy value to ensure that it is preserved in procedure
        set(s5, 7885);  // set some dummy value to ensure that it is preserved in procedure
        set(s6, 7886);  // set some dummy value to ensure that it is preserved in procedure
        set(s7, 7887);  // set some dummy value to ensure that it is preserved in procedure
        run("fib", 10);
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"fib\" procedure, you used $s0 -- ", 7880, get(s0));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"fib\" procedure, you used $s1 -- ", 7881, get(s1));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"fib\" procedure, you used $s2 -- ", 7882, get(s2));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"fib\" procedure, you used $s3 -- ", 7883, get(s3));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"fib\" procedure, you used $s4 -- ", 7884, get(s4));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"fib\" procedure, you used $s5 -- ", 7885, get(s5));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"fib\" procedure, you used $s6 -- ", 7886, get(s6));
        assertEquals("\n\tYou must preserve any $sX register that you use in your \"fib\" procedure, you used $s7 -- ", 7887, get(s7));
    }
    
    @Test(timeout=1000)  // 301
    public void verify_stack_pointer_after_calling_fib() {
        run("fib", 10);
        assertEquals("\n\tAfter calling \"fib\" procedure, stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    
    @Test(timeout=1000)  // 302
    public void verify_fib_procedure_when_n_is_5() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("fib", 5);
        assertEquals("\n\tWhen calling \"fib(5)\", return value should be 5 -- ", 5, get(v0));
    }
    
    @Test(timeout=5000)  // 303
    public void verify_fib_procedure_when_n_is_20() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("fib", 20);
        assertEquals("\n\tWhen calling \"fib(20)\", return value should be 6765 -- ", 6765, get(v0));
    }
    
    @Test(timeout=1000)  // 304
    public void verify_fib_procedure_when_n_is_1() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("fib", 1);
        assertEquals("\n\tWhen calling \"fib(1)\", return value should be 1 -- ", 1, get(v0));
    }
    
    @Test(timeout=1000)  // 305
    public void verify_fib_procedure_when_n_is_0() {
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("fib", 0);
        assertEquals("\n\tWhen calling \"fib(0)\", return value should be 0 -- ", 0, get(v0));
    }    
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Main Tests
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 306
    public void verify_arguments_are_passed_to_fib_procedure() {
        set(s0, 8);
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("ece260_main");
        assertEquals("\n\tWhen calling \"fib(8)\", return value should be 21. Make sure $a0 register is populated -- ", 21, get(v0));
    }

    @Test(timeout=1000)  // 307
    public void verify_final_result_stored_properly() {
        set(s0, 8);
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("ece260_main");
        assertEquals("\n\tWhen calling \"fib(8)\" procedure, return value should be stored in $s1 -- ", 21, get(s1));
    }
    
    @Test(timeout=1000)  // 308
    public void verify_stack_pointer_after_running_complete_program() {
        set(s0, 8);
        set(v0, 9999);  // set some dummy return value to ensure that it gets overwritten
        run("ece260_main");
        assertEquals("\n\tAfter running program, stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    //////////////////////////////////////////////////////////////////////////////////////////

}
